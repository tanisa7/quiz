const questions = [
    {
        question: "What is your favorite color?",
        answers: [
            { text: "Red", Season: "Summer", image: "https://th.bing.com/th/id/OIP.uvl3BFwV6fSiAaCK43d9GAHaEo?rs=1&pid=ImgDetMain" },
            { text: "Yellow", Season: "Winter", image: "https://th.bing.com/th/id/OIP.ZUwIPwnG266AsR6JY1L18AAAAA?rs=1&pid=ImgDetMain" },
            { text: "Blue", Season: "Spring", image: "https://www.ledr.com/colours/blue.jpg" },
            { text: "Green", Season: "Monsoon", image: "https://vignette.wikia.nocookie.net/joke-battles/images/0/0e/Green.jpg/revision/latest?cb=20170111231844" },
            {text: "Pink" , Season: "Fall" , image:"https://th.bing.com/th/id/R.0a6016dc3cdc6370116bf0a551f844d5?rik=vHtdSYZY3agBpg&riu=http%3a%2f%2fwww.solidbackgrounds.com%2fimages%2f2560x1440%2f2560x1440-deep-pink-solid-color-background.jpg&ehk=lgUAjJZjmpptJxkQlIpbpkcAyyCqHy04QgOWYqiwEZ4%3d&risl=&pid=ImgRaw&r=0"}
        ]
    },
    {
        question: "What's your favorite food?",
        answers: [
            { text: "Pizza", Season: "Summer", image: "https://th.bing.com/th/id/OIP.-gTvDVrcnOK747nnJabFoQHaE8?rs=1&pid=ImgDetMain" },
            { text: "Burger", Season: "Winter", image: "https://th.bing.com/th/id/OIP.g_EYshV4TBrKFonMmN2KEgHaE7?rs=1&pid=ImgDetMain" },
            { text: "Chicken Nuggets", Season: "Spring", image: "https://th.bing.com/th/id/OIP.9ZfuMH16ujHNn-alkvnngwHaE8?rs=1&pid=ImgDetMain" },
            { text: "Fish Finger", Season: "Monsoon", image: "https://static.independent.co.uk/s3fs-public/thumbnails/image/2015/09/12/21/29-fish-fingers-rex.jpg" },
            {text: "muffins" , Season: "Fall" , image:"https://eskipaper.com/images/muffins-cream-sweets-dessert-rose-flower-1.jpg"}
        ]
    },
    {
        question: "What's your favorite destination?",
        answers: [
            { text: "Paris", Season: "Summer", image: "https://th.bing.com/th/id/OIP.D-PRrefMDMZR-mcatEGLMQAAAA?rs=1&pid=ImgDetMain" },
            { text: "Japan", Season: "Winter", image: "https://th.bing.com/th/id/OIP.se1T2oDs73nOx3syBgPimgHaE7?rs=1&pid=ImgDetMain" },
            { text: "NYC", Season: "Spring", image: "https://th.bing.com/th/id/OIP.y_LM1jblSHVSbu8uNL9JvAHaEY?rs=1&pid=ImgDetMain" },
            { text: "Vietnam", Season:"Monsoon", image :"https://th.bing.com/th/id/OIP.MpZcNVT66fEHQVsieEBm0AAAAA?rs=1&pid=ImgDetMain"},
            {text: "Manali" , Season: " Fall " , image :"https://th.bing.com/th/id/OIP.wcOyfoUyccLm-UvoNtNLsAHaE4?rs=1&pid=ImgDetMain"}
        ]
    },
    {
        question: "What's your favorite animal?",
        answers: [
            { text: "Cat", Season: "Winter", image :"./images/99c994b9-3461-4223-99aa-a09dbfe7f32e.jpg" },
            { text: "Golden Retriever", Season: "Summer", image:"./images/d5ccd5cd-4597-4a82-81e1-61d7ddde7b44.jpg"  },
            { text: "Tiger", Season: "Spring", image:"./images/7177a93a-7321-4987-945c-260c63c78c92.jpg"  },
            { text: "Raccoon", Season: "Monsoon", image:"./images/b9aa61b3-eda0-4f0a-9aab-52ccaec0419b.jpg"},
            {text: "Giraffe" , Season:"Fall" , image :"./images/365ea343-0e81-4a81-ba6b-1b49bce505b0.jpg"}
        ]
    }
];

const results = {
    "Summer": {
        text: "You are a sunshine person, Summer suits you",
        image: "https://th.bing.com/th/id/OIP.PWtWUsafdJuuxOVNIPRJ2AHaE8?rs=1&pid=ImgDetMain"
    },
    "Winter": {
        text: "You love to be mysterious, Winter suits you",
        image: "https://th.bing.com/th/id/OIP.AJiOcWSuaDJ2RRAITcJciwHaFj?rs=1&pid=ImgDetMain"
    },
    "Spring": {
        text: "You love your friends and are a happy person, Spring suits you",
        image: "https://th.bing.com/th/id/OIP.9ZuQeB5SSNbFtSLx07bfIQHaEo?rs=1&pid=ImgDetMain"
    },
    "Monsoon": {
        text: "You love peace, Monsoon suits you",
        image: "https://th.bing.com/th/id/OIP.Seg5AvME4TzvBO9M8APl2AHaHa?pid=ImgDet&w=185&h=185&c=7&dpr=1.3"
    },
    "Fall":{
        text: " You love and embrace change , Fall suits you ",
        image:"https://th.bing.com/th/id/OIP._08ik2sYBv6_NyFZsFOEhgHaGl?rs=1&pid=ImgDetMain"
    }
};


let currentQuestionIndex = 0;
let selectedSeason = "";

const questionContainer = document.getElementById('question-container');
const nextButton = document.getElementById('next-btn');
const resultContainer = document.getElementById('result-container');

function startQuiz() {
    currentQuestionIndex = 0;
    selectedSeason = "";
    nextButton.innerText = "Next";
    nextButton.style.display = 'none';
    showQuestion();
}

function showQuestion() {
    resetState();
    const currentQuestion = questions[currentQuestionIndex];
    const questionElement = document.createElement('div');
    questionElement.className = 'question';
    questionElement.innerText = currentQuestion.question;
    questionContainer.appendChild(questionElement);

    const optionsElement = document.createElement('ul');
    optionsElement.className = 'options';
    currentQuestion.answers.forEach(answer => {
        const optionElement = document.createElement('li');

        const imgElement = document.createElement('img');
        imgElement.src = answer.image;
        imgElement.alt = answer.text;
        imgElement.className = 'option-image';

        const textElement = document.createElement('span');
        textElement.innerText = answer.text;

        optionElement.appendChild(imgElement);
        optionElement.appendChild(textElement);
        optionElement.addEventListener('click', () => selectAnswer(answer.Season));
        optionsElement.appendChild(optionElement);
    });

    questionContainer.appendChild(optionsElement);
    questionContainer.style.display = 'block';
}

function resetState() {
    nextButton.style.display = 'none';
    questionContainer.innerHTML = '';
    resultContainer.style.display = 'none';
    resultContainer.innerHTML = '';
}

function selectAnswer(season) {
    selectedSeason = season;
    if (currentQuestionIndex < questions.length - 1) {
        nextButton.style.display = 'block';
    } else {
        showResult();
    }
}

nextButton.addEventListener('click', () => {
    currentQuestionIndex++;
    showQuestion();
});

function showResult() {
    resetState();
    questionContainer.style.display = 'none';

    const result = results[selectedSeason];

    const resultText = document.createElement('p');
    resultText.textContent = result.text;

    const resultImage = document.createElement('img');
    resultImage.src = result.image;
    resultImage.alt = selectedSeason;
    resultImage.className = 'result-image';

    resultContainer.appendChild(resultText);
    resultContainer.appendChild(resultImage);
    resultContainer.style.display = 'block';
}


startQuiz();
